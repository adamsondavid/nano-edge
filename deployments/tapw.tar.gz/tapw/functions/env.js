export default {
  GREETING: "Hello there!",
};
