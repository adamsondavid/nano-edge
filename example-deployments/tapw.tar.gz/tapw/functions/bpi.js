export default async function(req) {
  return fetch("http://storage/deployments/tapw.tar.gz");
}
