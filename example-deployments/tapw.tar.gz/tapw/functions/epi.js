export default async function(req) {
  return fetch("https://google.de");
}
